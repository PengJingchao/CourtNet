import cv2
import os

import numpy as np
from torch.utils.data.dataset import Dataset

from config import config


class G1G2Dataset(Dataset):
    def __init__(self, mode):
        self.mode = mode

        self.imageset_dir = os.path.join('./make_pic/')
        self.imageset_gt_dir = os.path.join('./make_pic/')

    def __len__(self):
        return 1764

    def __getitem__(self, idx):
        img_dir = os.path.join(self.imageset_dir, "%04d.png" % int(idx+1))
        gt_dir = os.path.join(self.imageset_gt_dir, "%04d.png" % int(idx+1))

        real_input = np.float32(cv2.imread(img_dir,0)) / 255.0
        real_input = cv2.resize(real_input, (224, 224))

        if config.ReadColorImage == 0:
            input_images = real_input * 2 - 1
        else:
            input_images = real_input * 2 - 1
            input_images = np.expand_dims(input_images, axis=0)

        bufImg = cv2.imread(gt_dir, -1)
        # bufImg = cv2.resize(bufImg, (224, 224), interpolation=cv2.INTER_NEAREST_EXACT)
        dilated_bufImg = bufImg
        output_images = np.float32(dilated_bufImg) / 255.0  # 像素归一化
        output_images = np.expand_dims(output_images, axis=0)

        sample_info = {}
        sample_info['input_images'] = input_images
        sample_info['output_images'] = output_images

        return sample_info